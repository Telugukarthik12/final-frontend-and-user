export class Placemodel {
    
        placeId:number=0;
        placeName:string="";
        images:string="0";
        address:string="";
        area:string="";
        distance:number=0;
        description:string="";
        tags:string="";
        isSelected:boolean=false;
       
        constructor(){
            
        }
    
}
