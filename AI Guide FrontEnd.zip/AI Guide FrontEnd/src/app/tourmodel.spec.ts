import { Tourmodel } from './tourmodel';

describe('Tourmodel', () => {
  it('should create an instance', () => {
    expect(new Tourmodel()).toBeTruthy();
  });
});
