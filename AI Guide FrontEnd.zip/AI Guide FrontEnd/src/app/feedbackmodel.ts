export class Feedbackmodel {

    placeId: number=0;
    userId: number=0;
    feedbackText: string="";
    dateTime: Date=new Date;

}
